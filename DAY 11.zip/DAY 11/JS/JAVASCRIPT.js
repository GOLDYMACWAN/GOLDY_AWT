$(document).ready(function(){
    $("#id1").click(function(){
       $("#ID").hide(3000); /* takes 3000 mili second time to hide*/
       $(this).attr("disabled",true); 
        $("#id2").attr("disabled",false);
    });


    $("#id2").click(function(){
        
        $("#ID").show(3000);
        $(this).attr("disabled",true); 
        $("#id1").attr("disabled",false);
    });

    $(document).ready(function () {
        $("#id3").click(function () {
            $(this).attr("disabled",true); 
            $("#id4").attr("disabled",false);    
        });
        $("#id3").click(function () {
            var PLUS = parseInt($("#ID").css("height"));
            if (PLUS <= 500) {
                PLUS += 200;
                $("#ID").css("height", PLUS);
                $("#ID").css("width", PLUS);
            }
            else {
                alert("MOre then 500px is not possible");
            }
        });
    });
    
    $(document).ready(function () {
        $("#id4").click(function () {
            $(this).attr("disabled",true); 
            $("#id3").attr("disabled",false);   
        });
        $("#id4").click(function () {
            var MINUS = parseInt($("#ID").css("height"));
            if (MINUS <= 20) {
                MINUS -= 10;
                $("#ID").css("height", MINUS);
                $("#ID").css("width", MINUS);
            }
            else {
                alert("Less then 20px is not possible");
            }
    
        });
    })
});