function externalalertjs(){
    alert('Hello');
}
function externalconfirmjs(){
    confirm('do you want to download it?');
}
function externalprompt(){
    prompt('enter here');
}
console.log("Hello everyone");
func
document.body.style.backgroundColor="black";

function bgalert(){
    document.getElementById('id1').style.backgroundColor="lightgreen";
    document.getElementById('id1').style.color="red";
}

function bgclr(){
document.getElementById('id2').style.backgroundColor=prompt("enter your color");
}

function onchng(){
  document.getElementById('id11').style.backgroundColor="blue";
  
}

function chang(){
    document.body.style.backgroundColor=document.getElementById('id01').value;
}
function bgchnge(){
    document.getElementById('ido').style.backgroundColor=document.getElementById('id12').value;
}

function ID1(){
    var vname=prompt("enter Name");
    document.getElementById('id111').innerHTML=vname;
    document.getElementById('id111').style.backgroundColor="lightgreen";
    document.getElementById('ID1').style.backgroundColor="orange";
}
function ID2(){
    var vname=prompt("Enter Your Name");
    document.getElementById('id123').innerHTML=vname;
}

